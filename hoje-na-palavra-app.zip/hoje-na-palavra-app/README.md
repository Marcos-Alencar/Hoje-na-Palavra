# ✦ Hoje na Palavra v3.0

> Reflexões bíblicas diárias geradas com Inteligência Artificial

---

## 🚀 Como usar

### Opção 1 — Abrir direto no navegador
Basta abrir o arquivo `index.html` em qualquer navegador moderno.
> ⚠️ Alguns navegadores bloqueiam requisições locais. Se o app não carregar o `app.jsx`, use a Opção 2.

### Opção 2 — Servidor local (recomendado)
```bash
# Python (já vem instalado na maioria dos sistemas)
python3 -m http.server 8080

# Node.js
npx serve .

# VS Code
# Instale a extensão "Live Server" e clique em "Go Live"
```
Depois acesse: **http://localhost:8080**

---

## 📁 Estrutura de arquivos

```
hoje-na-palavra-app/
├── index.html     ← Página principal (abre no navegador)
├── app.jsx        ← Toda a lógica e UI do app
└── README.md      ← Este arquivo
```

---

## ✨ Funcionalidades

- 📖 **Devocional diário** gerado por IA (Claude como fallback automático)
- 🗓️ **Navegação por datas** — veja devocionais anteriores, sem datas futuras
- ❤️ **Favoritos** — salve e reveja seus devocionais preferidos
- 📤 **Compartilhar** — via Web Share API ou cópia para clipboard
- 🌙 **Modo escuro/claro** com transição suave
- 🌍 **3 idiomas** — Português (BR), English, Español
- ⚡ **Cache offline** — devocionais salvos no localStorage por data + idioma
- 🔔 **Notificações diárias** às 8h da manhã (requer permissão do navegador)
- 🤖 **Chave Universal de IA** — compatível com OpenAI, Gemini, Claude, LiteLLM

---

## 🔑 Configurando sua chave de IA

1. Abra o app e vá em **Configurações** (ícone de engrenagem)
2. Role até **Chave de IA**
3. Cole sua chave (ex: `sk-...` para OpenAI)
4. Clique em **Salvar**

Sem chave: o app usa **Claude** internamente como fallback automático.

---

## 🔔 Notificações Push (Produção)

Para notificações reais em produção, integre com:
- **Firebase Cloud Messaging (FCM)** — para Android/Web
- **Expo Push Notifications** — para React Native
- **Web Push API** com um service worker

No modo atual (web puro), as notificações usam `setTimeout` e funcionam apenas com o navegador aberto.

---

## 🛠️ Tecnologias

| Tecnologia | Uso |
|---|---|
| React 18 (CDN) | Interface |
| Babel Standalone | Transpilação JSX no browser |
| Anthropic Claude API | Geração de conteúdo (fallback) |
| OpenAI-compatible API | Geração com chave própria |
| localStorage | Cache + favoritos + configurações |
| Web Share API | Compartilhamento nativo |
| Notifications API | Notificações do navegador |

---

## 📱 Deploy gratuito

Faça deploy em segundos com qualquer plataforma de hospedagem estática:

- **Netlify**: arraste a pasta para [netlify.com/drop](https://netlify.com/drop)
- **Vercel**: `vercel --prod`
- **GitHub Pages**: suba os arquivos e ative Pages nas configurações
- **Cloudflare Pages**: conecte o repositório

---

*Hoje na Palavra v3.0 — Feito com ❤️ e IA*
